/*CONDICIONALES
Mayor de edad*/
#include <stdio.h>

int main(){
	int a;
	printf("Digite su edad:\n");
	scanf("%d",&a);
	
	if(a>=18){
		printf("Bienvenido a la front");
	}else{
		printf("Eres menor de edad, no puedes ir a la front\n");
	}
return 0;	
}
