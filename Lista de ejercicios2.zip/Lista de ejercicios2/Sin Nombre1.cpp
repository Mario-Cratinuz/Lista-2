/*Hola mundo personalizado*/
#include <stdio.h>
int main(){
	char nom[30];
	printf("Digite su nombre:\n");
	scanf("%50s",&nom);
	printf("Hola %s\n",nom);
	
	return 0;
}
