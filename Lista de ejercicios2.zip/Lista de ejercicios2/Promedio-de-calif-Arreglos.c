/*Promedio de calificaciones*/
#include <stdio.h>
int main(){
	int calif[3]={5,8,6}, a, i;
	for (i=0 ;i<=3;i++){
		a += calif[i];		
	}
	printf("El promedio es: %d", a/3);
	
	return 0;
}
