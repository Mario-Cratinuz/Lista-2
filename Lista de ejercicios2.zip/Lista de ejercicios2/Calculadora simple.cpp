/*Calculadora simple*/
#include <stdio.h>
int main(){
	int a,b, suma, resta, mult, div;		
	printf("Este programa te da una calculadora, muy simple.");
	printf("Digite dos numeros enteros:\n");
	scanf("%d%d", &a,&b);
	suma = a+b;
	resta= a-b;
	mult=a*b;
	div= a/b;
	printf("La suma es %d\nLa resta es %d\nLa multiplicacion es %d\nLa division es %d\n", suma, resta, mult, div);
	return 0;
}

