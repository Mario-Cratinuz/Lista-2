/*Conversor de unidades*/
#include <stdio.h>
int main (){
	float a, pul, res;
	pul = 0.3937;
	printf("\tEste programa es un conversor de unidades de cm a pulgadas.\n");
	printf("Digite un numero:\n");
	scanf("%f", &a);//No pongas %3f ni %.3f
	res = a*pul ;
	printf("El numero en pulgadas es: %.4f\n", res);
	
return 0;
}
