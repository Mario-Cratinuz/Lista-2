/*Bucles
Tabla de multiplicar de un numero dado */
#include <stdio.h>
int main(){
	int a,i;
	printf("Digite la tabla de multiplicar deseada:\n");
	scanf("%d",&a);
	printf("La tabla es\n");
	for(i = 0;i<=15;i++){
	printf("%d*%d=%d\n",a,i,a*i);		
	}	
	return 0;
}
