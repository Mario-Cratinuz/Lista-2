/*CONDICIONALES
Numero par e impar*/
#include <stdio.h>

int main(){
	int a;
	printf("Digite un numero entero para saber si es par o impar:\n");
	scanf("%d",&a);
	
	if(a%2==0){
		printf("El numero es par");
	}else{
		printf("El numero es impar");
	}
return 0;	
}
