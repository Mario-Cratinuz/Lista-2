/*Ejercicio 1.- Entrada y salida.
Calculadora personalizada*/
#include <stdio.h>
int main (){
    int a, b, num, suma, resta, mult, div;
    float mod;
    printf("Bienvenido a la calculadora hecha con mis manitas campesinas\n");
    printf("Digite dos numeros: ");
    scanf("%d%d", &a,&b);
    printf("Escriba que operacion desea realizar del 1 al 4:\n1.-Suma\n2.-Resta\n3.-Multiplicacion\n4.-Division\nDigite:");
    scanf("%d",&num);
	suma = a+b;
	resta = a-b;
	mult = a*b;
	div = a/b ;
	mod =a%b ;
    if (num == 1){
        printf("La suma es %d\n", suma);
    } else if(num == 2){
        printf("La resta es %d\n", resta);
    }else if(num == 3){
        printf("La multiplicacion es %d\n", mult);
    }else if(num == 4){
        printf("La division es %d\n",div);
        printf("El modulo es %.2f\n", mod);
    }else {
        printf("Operacion no reconocida, intente de nuevo:c\n\a");

    }

return 0;
}
