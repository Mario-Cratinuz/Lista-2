/*Suma de los primeros n numeros */
#include <stdio.h>
int main (){
	int a,i, suma= 0;
	printf("Digite el numero de la suma\n");
	scanf("%d",&a);
	
	for ( i = 0 ; i<=a; i++){
		suma += i; //suma = suma + i;
	}
	printf("La suma es %d\n", suma);
	return 0;
}
