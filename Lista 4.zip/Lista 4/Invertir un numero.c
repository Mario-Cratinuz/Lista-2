/*Invertir un numero*/
#include <stdio.h>
int main (){
	int num, rev=0;
	printf("Digite un numero:\n");
	scanf("%d",&num);
	while(num>0){
		rev = rev *10 + num %10;
		/*Multiplicamos rev por 10 para mover sus d�gitos actuales una posici�n a la izquierda.
Luego, sumamos el �ltimo d�gito de num para "a�adirlo al final" de rev.
Ejemplo:
Inicialmente, rev = 0.
Para num = 123, se obtiene 3 del num % 10.
Entonces, rev = 0 * 10 + 3 = 3.
En la siguiente iteraci�n, si num = 12, se obtiene 2.
Ahora, rev = 3 * 10 + 2 = 32.*/ 
		num /= 10;
	}
	printf("El inverso es %d\n",rev);
	return 0;
}
