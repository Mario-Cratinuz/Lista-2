//Tabla de multiplicar
#include <stdio.h>
int main(){
	int a,i;
	printf("Digite el numero de la tabla deseada:\n");
	scanf("%d" , &a);
	printf("La tabla de %d es:\n",a);
//	for(i=1;i<=10;i++){
//	printf("%d * %d = %d\n",a,i,a*i);
//	}
	while(i<=10){
		printf("%d*%d=%d\n",a,i,a*i);
		i++;
	}
	return 0;
}
