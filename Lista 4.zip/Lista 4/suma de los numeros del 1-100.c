#include <stdio.h>
int main(){
	int i;
	int suma=0;
	for (i=0;i<=100;i++){
		suma += i;
	}
	printf("La suma es %d\n", suma);
	return 0;
}
