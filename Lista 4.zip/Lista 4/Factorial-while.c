/*Factorial de un numero usando un while*/
#include <stdio.h>
int main(){
	int n, factorial=1;
	printf("Digite un numero:\n");
	scanf("%d",&n);
	
	while(n>0){
		factorial *= n;
		n--;
	}
	printf("El factorial es %d\n", factorial);
	
	return 0;
}
