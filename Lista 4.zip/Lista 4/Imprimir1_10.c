/*Imprimir los numeros del 1-10 con un ciclo for*/
#include <stdio.h>
int main(){
	int i;
	for (i=0;i<=10;i++){
		printf("%d\t",i);
	}
	
	return 0;
}
