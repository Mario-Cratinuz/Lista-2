//Imprimir los primeros 10 multiplos de un numero
#include <stdio.h>
int main(){
	int a,i;
	printf("Digite un numero:\n");
	scanf("%d", &a);
	printf("La tabla %d con los primeros 10 multiplos:\n",a);
	for(i=1;i<=10;i++){
		printf("%d * %d = %d\n",a ,i , a*i);
	}
	return 0;
}
