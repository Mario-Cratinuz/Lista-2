/*Determinar si un numero es primo*/
#include <stdio.h>
#include <math.h>
int main(){
	int i,a,cont=0; 
	printf("Digite un numero:\n");
	scanf("%d",&a);
	for(i=1;i<=a;i++){
		if(a % i == 0){
		cont ++;
		}
	}
	if (cont>2){
			printf("El numero no es primo\n");
	}else{
			printf("El numero es primo\n");
	}
	return 0;
}
