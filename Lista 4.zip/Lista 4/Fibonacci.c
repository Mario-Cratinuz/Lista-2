/**/
#include <stdio.h>
int main(){
	
	int a = 0,b = 1,c,n,i, suma=0;
	printf("Digite un numero:\n");
	scanf("%d",&n);
	
	for(i = 0;i< n;i++){
		printf("%d",a);
		suma += a;
		c = a+b;
		a = b ;
		b = c ;
	}
	printf("La suma en fibonacci es %d", suma);
	return 0;
}
